//
//  Person.m
//  Game
//
//  Created by Won Suk Choi on 2017. 1. 17..
//  Copyright © 2017년 Won Suk Choi. All rights reserved.
//

#import "Person.h"

@implementation Person

- (id)think {
    NSLog(@"생각을 합니다.");
    return nil;
}

- (id)eat {
    NSLog(@"먹습니다.");
    return nil;
}

- (id)laugh {
    NSLog(@"웃습니다");
    NSLog(@"깔깔깔깔");
    return nil;
}
@end
