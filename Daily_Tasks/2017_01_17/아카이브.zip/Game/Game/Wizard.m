//
//  Wizard.m
//  Game
//
//  Created by Won Suk Choi on 2017. 1. 17..
//  Copyright © 2017년 Won Suk Choi. All rights reserved.
//

#import "Wizard.h"

@implementation Wizard

- (id)physicalAttack {
    NSLog(@"물리공격을 사용합니다.");
    return nil;
}

- (id)magicalAttack {
    NSLog(@"마법공격을 사용합니다.");
    return nil;
}

@end
