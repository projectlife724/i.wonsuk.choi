//
//  Person.h
//  Game
//
//  Created by Won Suk Choi on 2017. 1. 17..
//  Copyright © 2017년 Won Suk Choi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject

@property id name;

- (id)think;
- (id)eat;
- (id)laugh;
- (id)punch;

@end
