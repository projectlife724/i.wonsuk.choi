//
//  Daily.h
//  Day_2_OOP
//
//  Created by Won Suk Choi on 2017. 1. 17..
//  Copyright © 2017년 Won Suk Choi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Daily : NSObject

@property id timeTable;
@property id dailySchedule;
@property id date;
@property id dailyNotes;
@property id priority;
@property id day;

- (id)changePriority;
- (id)changeSchedule;
- (id)createNotes;
- (id)createSchedule;

@end
