//
//  Monthly.m
//  Day_2_OOP
//
//  Created by Won Suk Choi on 2017. 1. 17..
//  Copyright © 2017년 Won Suk Choi. All rights reserved.
//

#import "Monthly.h"

@implementation Monthly

@end
