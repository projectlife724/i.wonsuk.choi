//
//  Person.h
//  Day_2_OOP
//
//  Created by Won Suk Choi on 2017. 1. 17..
//  Copyright © 2017년 Won Suk Choi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject

// Property of a Person
// In the Database of a MatchMaking Firm

@property id name;
@property id sex;
@property id age;
@property id height;
@property id skinColor;
@property id religion;
@property id asset;
@property id discountedCashFlow;
@property id school;
@property id job;

- (id)brainStorming;
- (id)creativeThinking;
- (id)criticalThinking;
- (id)dreaming;
- (id)obeyingLaw;
- (id)programming;
- (id)learning;
- (id)developing;

@end
