//
//  Weekly.h
//  Day_2_OOP
//
//  Created by Won Suk Choi on 2017. 1. 17..
//  Copyright © 2017년 Won Suk Choi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Weekly : NSObject

@property id weekView;
@property id weeklyNotes;
@property id weeklySchedule;
@property id weeklySummary;
@property id doneTasks;

- (id)writeNotes;
- (id)writeSchedule;
- (id)writeSummary;

@end
