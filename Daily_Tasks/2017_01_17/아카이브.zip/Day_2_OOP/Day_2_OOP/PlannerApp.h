//
//  Planner.h
//  Day_2_OOP
//
//  Created by Won Suk Choi on 2017. 1. 17..
//  Copyright © 2017년 Won Suk Choi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PlannerApp : NSObject

@property id pageDesign;
@property id font;
@property id schedule;
@property id notes;

- (id)alarm;
- (id)notify;
- (id)indicateScheduleName;
- (id)indicateScheduleTime;


@end
